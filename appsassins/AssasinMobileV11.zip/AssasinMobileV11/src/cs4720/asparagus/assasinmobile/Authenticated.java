package cs4720.asparagus.assasinmobile;

public class Authenticated {
	String token_type;
	String access_token;
}