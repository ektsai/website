package cs4720.asparagus.assasinmobile;

import java.util.ArrayList;


//a collection of tweets
public class Twitter extends ArrayList<Tweet> {
	private static final long serialVersionUID = 1L;
}
