/** Automatically generated file. DO NOT MODIFY */
package cs4720.asparagus.assasinmobile;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}