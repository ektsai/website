<form method="get" class="search-form" action="<?php echo esc_url( home_url( '/' ) ); ?>">
	<input type="search" placeholder="<?php _e('Search form', 'radcliffe'); ?>" name="s" id="s" /> 
	<input type="submit" id="searchsubmit" value="<?php _e('Search', 'radcliffe'); ?>" class="search-button">
</form>