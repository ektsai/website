<form method="get" class="search-form" action="<?php echo esc_url( home_url( '/' ) ); ?>">
	<label for="search-field" class="genericon genericon-search"></label>
	<input type="search" value="" placeholder="<?php _e('Search form', 'garfunkel'); ?>" name="s" class="search-field" id="search-field" /> 
</form>