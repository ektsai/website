package edu.virginia.cs4240.todaysevents;

import java.text.SimpleDateFormat;
import java.util.Calendar;

import android.util.Log;

public class EventFactory {

	private String title;
	private String starttime;
	private String endtime;
	// Calendar starttime;
	// Calendar endtime;
	private String description;
	private String location;
	private String state;
	private int id;
	private String type;

	public EventFactory(String title, String starttime, String endtime,
			String description, String location, String type, int id) {
		this.title = title;
		this.starttime = starttime;
		this.endtime = endtime;
		this.description = description;
		this.location = location;
		this.id = id;
		this.type = type;

	}

	public Event createEvent() {

		Event event = null;
		Calendar timestart = Calendar.getInstance();
		Calendar timeend = Calendar.getInstance();
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		try {
			timestart.setTime(sdf.parse(this.starttime));
			timeend.setTime(sdf.parse(this.endtime));
		} catch (Exception e) {
			Log.e("String to Calendar: ", e.toString());
		}
		//System.out.println(this.starttime);
		if (type.equals("sports")) {
			event = new SportEvent(title, timestart, timeend, description,
					location, id);
		} else if (type.equals("academic")) {
			event = new AcademicEvent(title, timestart, timeend, description,
					location, id);
		} else if (type.equals("entertainment")) {
			event = new EntertainmentEvent(title, timestart, timeend,
					description, location, id);
		} else {
			event = new GenericEvent(title, timestart, timeend,
					description, location, id, type);
		}
		return event;
	}

}
