package edu.virginia.cs4240.todaysevents;

import java.util.Calendar;

public class GenericEvent extends Event{
	
	public GenericEvent(String title, Calendar starttime,
			Calendar endtime, String description, String location, int id, String type) {

		this.title = title;
		this.starttime = starttime;
		this.endtime = endtime;
		this.description = description;
		this.location = location;
		this.id = id;
		this.type = type;
	}
	
}
