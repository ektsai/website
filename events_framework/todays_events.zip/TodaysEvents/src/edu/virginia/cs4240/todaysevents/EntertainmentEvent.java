package edu.virginia.cs4240.todaysevents;

import java.text.SimpleDateFormat;
import java.util.Calendar;

public class EntertainmentEvent extends Event {

	public EntertainmentEvent(String title, Calendar starttime,
			Calendar endtime, String description, String location, int id) {

		this.title = title;
		this.starttime = starttime;
		this.endtime = endtime;
		this.description = description;
		this.location = location;
		this.type = "entertainment";
		this.id = id;
	}

//	@Override
//	public String toString(){
//		
//		SimpleDateFormat sdf = new SimpleDateFormat("MM/dd-HH:mm:ss");
//
//		String st = sdf.format(starttime.getTime());
//		String et = sdf.format(endtime.getTime());
//
//		return title +" ("+type+")\n[" + state+ "]\n*"+ st	+ " to " + et + "\n*Location!!! @ " + location +"\n*" + description;
//	}
}
