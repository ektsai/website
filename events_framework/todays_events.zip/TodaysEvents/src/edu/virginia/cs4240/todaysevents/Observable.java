package edu.virginia.cs4240.todaysevents;

public interface Observable {
	
	public void updateAll();
	public void addEvent(Event e);
	public boolean removeEvent(Event e);
}
