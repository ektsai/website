package edu.virginia.cs4240.todaysevents;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonParser;

import android.app.Activity;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup.LayoutParams;
import android.widget.AdapterViewFlipper;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;

public class HomeActivity extends Activity {

	ArrayList<Event> theList;
	EventManager eventManager;
	String webserviceURL = "http://plato.cs.virginia.edu/~sh4fd/cake/events/main";
	LinearLayout linear;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_home);
		theList = new ArrayList<Event>();
		eventManager = EventManager.getInstance();

		new GetEventsTask().execute(webserviceURL);

//		final Button bn = (Button) findViewById(R.id.button1);
//		bn.setOnClickListener(new OnClickListener() {
//			@Override
//			public void onClick(View v) {
//				new GetEventsTask().execute(webserviceURL);
//			}
//		});		
	}
	
	@Override
	public void onResume(){
		super.onResume();
		new GetEventsTask().execute(webserviceURL);
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		getMenuInflater().inflate(R.menu.activity_home, menu);
		return true;
	}

	public static String getJSONfromURL(String url) {

		// initialize
		InputStream is = null;
		String result = "";

		// http post
		try {
			HttpClient httpclient = new DefaultHttpClient();
			HttpPost httppost = new HttpPost(url);
			HttpResponse response = httpclient.execute(httppost);
			HttpEntity entity = response.getEntity();
			is = entity.getContent();

		} catch (Exception e) {
			Log.e("JSON parse", "Error in http connection " + e.toString());
		}

		// convert response to string
		try {
			BufferedReader reader = new BufferedReader(new InputStreamReader(
					is, "iso-8859-1"), 8);
			StringBuilder sb = new StringBuilder();
			String line = null;
			while ((line = reader.readLine()) != null) {
				sb.append(line + "\n");
			}
			is.close();
			result = sb.toString();
		} catch (Exception e) {
			Log.e("JSON parse", "Error converting result " + e.toString());
		}

		return result;
	}

	private class GetEventsTask extends AsyncTask<String, Integer, String> {

		@Override
		protected void onPreExecute() {
		}

		@Override
		protected String doInBackground(String... params) {

			String url = params[0];
			EventFactory eventFactory;
			try {

				String webJSON = getJSONfromURL(url);
				System.out.println(url);

				Gson gson = new Gson();

				JsonParser parser = new JsonParser();
				JsonArray Jarray = parser.parse(webJSON).getAsJsonArray();

				eventManager.clear();
				for (JsonElement obj : Jarray) {
					eventFactory = gson.fromJson(obj, EventFactory.class);				
					Event event = eventFactory.createEvent();
					eventManager.addEvent(event);
				}

			} catch (Exception e) {
				Log.e("Hello", "JSONPARSE:" + e.toString());
			}

			eventManager.updateAll();

			return "Done!";
		}

		@Override
		protected void onProgressUpdate(Integer... ints) {

		}

		@Override
		protected void onPostExecute(String result) {
			// after execution of reading in json data

			HashMap<String,ArrayList<Event>> eventArrays = eventManager.getEventLists();
			linear = new LinearLayout(HomeActivity.this);
			linear.setOrientation(LinearLayout.VERTICAL);

			//dynamically create a view
			for (String type : eventArrays.keySet())
			{
				ArrayAdapter<Event> adapter = new ArrayAdapter<Event>(HomeActivity.this,
						android.R.layout.simple_list_item_1, android.R.id.text1, eventArrays.get(type));

				LinearLayout linear2 = new LinearLayout(HomeActivity.this);
				ListView listView = new ListView(HomeActivity.this);
				linear2.addView(listView);
				linear2.setLayoutParams(new LinearLayout.LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT, 1));							
				
				//grey dividers
				View v = new View(HomeActivity.this);
				v.setLayoutParams(new LinearLayout.LayoutParams(LayoutParams.MATCH_PARENT, 5, 0));							
				v.setBackgroundResource(android.R.color.darker_gray);
				
				linear.addView(linear2);
				linear.addView(v);
				listView.setAdapter(adapter);
				adapter.notifyDataSetChanged();
			}
			linear.setWeightSum(eventArrays.keySet().size());
			Button bn = new Button(HomeActivity.this);
			bn.setText("Update");
			bn.setOnClickListener(new OnClickListener() {
				@Override
				public void onClick(View v) {
					new GetEventsTask().execute(webserviceURL); 
				}
			});	
			
			linear.addView(bn);
			setContentView(linear);
		}
	}
}
