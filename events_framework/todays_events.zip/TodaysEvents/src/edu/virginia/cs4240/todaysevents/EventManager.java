package edu.virginia.cs4240.todaysevents;

import java.util.ArrayList;
import java.util.HashMap;

public class EventManager implements Observable {

	private HashMap<String,ArrayList<Event>> eventArrays;
	private static EventManager instance;

	private EventManager()
	{
		eventArrays = new HashMap<String,ArrayList<Event>>();
	}

	public static synchronized EventManager getInstance()
	{
		if (instance==null)
			instance = new EventManager();
		return instance;
	}

	public ArrayList<Event> getEventList(String type)
	{
		return eventArrays.get(type);
	}

	public HashMap<String, ArrayList<Event>> getEventLists()
	{
		return eventArrays;
	}
	public void setEventList(ArrayList<Event> list, String type)
	{
		eventArrays.put(type, list);
	}

	@Override
	public void addEvent(Event e)
	{
		if(eventArrays.containsKey(e.type))
		{
			//prevent duplicates
			if (!eventArrays.get(e.type).contains(e))
			{
				eventArrays.get(e.type).add(e);
			}
		}
		else
		{
			ArrayList<Event> newArray = new ArrayList<Event>();
			newArray.add(e);
			eventArrays.put(e.type, newArray);
		}
	}

	@Override
	public boolean removeEvent(Event e)
	{
		if(eventArrays.containsKey(e.type))
		{
			eventArrays.get(e.type).remove(e);
			return true;
		}
		return false;
	}

	@Override //updates all the event statuses
	public void updateAll() {
		for (String type : eventArrays.keySet())
		{
			for( Event e : eventArrays.get(type))
			{
				e.update();
			}
		}
	}
	
	public void clear()
	{
		eventArrays.clear();
	}

}
