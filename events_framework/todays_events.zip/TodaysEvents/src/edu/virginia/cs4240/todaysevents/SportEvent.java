package edu.virginia.cs4240.todaysevents;

import java.util.Calendar;

public class SportEvent extends Event {

	public SportEvent(String title, Calendar starttime, Calendar endtime,
			String description, String location, int id) {

		this.title = title;
		this.starttime = starttime;
		this.endtime = endtime;
		this.description = description;
		this.location = location;
		this.type="sports";
		this.id = id;
	}

}
