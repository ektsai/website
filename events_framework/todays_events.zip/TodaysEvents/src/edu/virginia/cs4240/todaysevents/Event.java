package edu.virginia.cs4240.todaysevents;

import java.text.SimpleDateFormat;
import java.util.Calendar;

public abstract class Event extends Object{
	protected String title;

	protected Calendar starttime;
	protected Calendar endtime;
	protected String description;
	protected String location;
	protected String state;
	protected int id;
	protected String type;

	public Event() {

	}
	
	@Override
	public boolean equals(Object o){
		if(o instanceof Event)
		{
			Event event2 = (Event)o;
			if(event2.id==this.id)
				return true;
		}
		return false;
	}
	@Override
	public String toString() {

		//SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		SimpleDateFormat sdf = new SimpleDateFormat("MM/dd-HH:mm:ss");

		String st = sdf.format(starttime.getTime());
		String et = sdf.format(endtime.getTime());

		return title +" ("+type+")\n[" + state+ "]\n*"+ st	+ " to " + et + "\n*Location @ " + location +"\n*" + description;

		/*return title + " ("+type+")"+ " from " + st	+ " to " + et + " -- " + description
		+ ". Location = " + location;
		return "Event [title=" + title + ", starttime=" + st
		+ ", endtime=" + et + ", description=" + description
		+ ", location=" + location + ", id=" + id + ", type=" + type
		+ "]";*/
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public Calendar getStarttime() {
		return starttime;
	}

	public void setStarttime(Calendar starttime) {
		this.starttime = starttime;
	}

	public Calendar getEndtime() {
		return endtime;
	}

	public void setEndtime(Calendar endtime) {
		this.endtime = endtime;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public void update() {
		Calendar rightNow = Calendar.getInstance();
		if (rightNow.compareTo(starttime) < 0) {
			this.setState("upcoming");
		} else if (rightNow.compareTo(starttime) > 0
				&& rightNow.compareTo(endtime) < 0) {
			this.setState("ongoing");
		} else {
			this.setState("over");
		}
	}

}
