/** Automatically generated file. DO NOT MODIFY */
package edu.virginia.cs4240.todaysevents;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}